import SignupBox from "@/sources/components/SignupBox";
import Head from "next/head";
import Script from "next/script";
import React from "react";

const Page = () => {
  return (
    <div>
      <SignupBox />
    </div>
  );
};

export default Page;
