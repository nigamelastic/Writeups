import LoginBox from "@/sources/components/LoginBox";
import React from "react";

const Page = () => {
  return (
    <div>
      <LoginBox />
    </div>
  );
};

export default Page;
